# SVP v1.0 RC2 Release Package

This package revises SVP v1.0 RC1 to add first-class OCR / visible-text observations and structured color observations as Core sections.

Start with:

- `spec/SVP_v1_0_RC2.md`
- `spec/review/SVP_v1_0_RC2_Review_Notes.md`
- `docs/SVP_v1_0_RC2_Repo_Update_Handoff.md`
- `docs/SVP_Implementation_Phases_RC2_Update/00_PAUSE_PHASE_03_PLUS.md`

Do not continue Phase 03+ implementation work until the RC2 OCR/color deltas are planned into validator, fixtures, index, builder, and first-video-trial acceptance.
